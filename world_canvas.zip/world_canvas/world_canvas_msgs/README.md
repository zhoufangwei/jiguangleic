world_canvas_msgs
=================

Messages and services for the world canvas framework
