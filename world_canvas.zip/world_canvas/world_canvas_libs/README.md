World canvas libraries
======================

Client libraries to access semantic maps within the world canvas framework.
